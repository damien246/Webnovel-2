// Données fictives de romans utilisés par le prototype
const novels = [
  {
    id: '1',
    title: "La Quête de l'Aurore",
    author: 'Auteur 1',
    description: 'Un récit épique dans un monde fantastique.',
    chapters: ['Chapitre 1', 'Chapitre 2', 'Chapitre 3'],
  },
  {
    id: '2',
    title: 'Chroniques du Futur',
    author: 'Auteur 2',
    description: 'Une aventure de science‑fiction passionnante.',
    chapters: ['Chapitre 1', 'Chapitre 2'],
  },
];